/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

class InductsForTheDay extends Component {

	state = {
			data: [],
			label: null,
			graphData: null
	}

	componentDidMount() {
		this.getRecentOrders();
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'inductsfortheday/'+ localStorage.getItem("user_id") +this.props.sorterRoute)
		 .then(res => {
			    console.log(res.data);
			    let label = res.data.inductsForTheDayList.map(list => list.currentDt);
			    let graphData = res.data.inductsForTheDayList.map(list => list.curr_value);
			    
			    console.log(graphData);
		        this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData
					        });
		   }).catch(function (error) {
				console.log(error);
		  });
	}

	render() {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Inducts for the day"}
				reloadable
				fullBlock
				>
					<div className="clearfix">
	                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
	                    <div className="d-flex">
	                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
	                        	<CircularProgressbar percentage={this.state.data.percentValue}
	                        						 text={`${this.state.data.percentValue}%`}
	                        						 backgroundPadding={10}
	                        						 styles={{ path: { stroke: 'rgba(135,0,56, ${this.state.data.percentValue/100})', strokeLinecap: 'butt' },
	                        							 	   text: { fill: '#121212', fontSize: '25px'},
	                        							 	   trail: { stroke: '#d7d7d7' },
	                        							 	   background: { fill: '#fffff' }
	                        						 }}
	                        	/>
	                        </div>
	                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
	                                <span className="counter-point">
	                                	{this.state.data.currentValue} / {this.state.data.goalValue}
	                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
	                                </span>
	                            </div>
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
	                                <TinyAreaChart
	                                    label="Visitors"
	                                    chartdata={this.state.graphData}
	                                    labels={this.state.label}
	                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
	                                    borderColor={hexToRgbA(ChartConfig.color.primary, 3)}
	                                    lineTension="0"
	                                    height={70}
	                                    gradient
	                                />
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </RctCollapsibleCard>
		);
	}
}

export default InductsForTheDay;
