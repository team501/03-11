/**
 * InductsForTheDay
 */
import React, { Component } from 'react';
import {Link} from 'react-router-dom'; 
//axios
import axios from 'axios';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from '../../assets/data/jsonDataConfig/Sorter/inductionStatusPerHourJson';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';
import barChartConfig from '../../assets/data/jsonDataConfig/inductStatusBarChartConfig.json';

//circular-progressbar
import CircularProgressbar from 'react-circular-progressbar';

//bar chart
import {Bar} from 'react-chartjs-2';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

class InductionStatus extends Component {
	constructor(props) {
		super(props);
		this.state = { barData: []
		};
	}
	
	/*
	* calling rest for the first time after mount
	* it will call render twice but update only once
	* Used to remove unsafe life cycle methods.
	*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	// recent orders
	getRecentOrders() {
		
		let query = `query GetUSSInductionStatus($startTime: Long!, $xMins: Int, $sorterId: String!) {
				    	getUSSInductionStatus(startTime: $startTime,xMins: $xMins, sorterId: $sorterId) {
							sorterId
							statuses{
						      status
						      inductsCount
						    }
						  }
					}`;
		
		let startTime = 201903221245;//dateFormat(new Date(), "yyyymmddHHMM");
		let xMins = 60;
		let sorterId = this.props.sorterId;
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, xMins, sorterId }
			})
		})
		.then(r => r.json())
		.then(data => { 

			let label = data.data.getUSSInductionStatus.statuses.map(data => data.status);
		    let value = data.data.getUSSInductionStatus.statuses.map(data => data.inductsCount);
		    console.log(label);
		    this.setState({ label: label,
				   			value: value,
						    isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ label: [],
				   			value: [],
				   			isLoading:false
						 }); 
		});
	}
	

	render() {
		
		//Check For color blind and change the color
				const { isColorBlind } = this.props;
				
				var backgroundColors = barChartConfig.backgroundColors
				var borderColors = barChartConfig.borderColors
				
				if(isColorBlind){			
					backgroundColors = barChartConfig.backgroundColorsCB
					borderColors = barChartConfig.borderColorsCB
				}
				
		let data = { 
						labels: this.state.label,
						datasets: [{ 
							backgroundColor:backgroundColors,
							borderColor: borderColors,		  			
							borderWidth: barChartConfig.borderWidth,
							hoverBackgroundColor: barChartConfig.hoverBackgroundColor, //Optional
							hoverBorderColor: barChartConfig.hoverBorderColor, //Optional
							data: this.state.value
						}]
				};
		
		return (
			<div>
				<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={"Induction status per hour"}
					fullBlock
				>
					<div className="col-md-10 col-xl-10 col-sm-10 col-ls-10 float-left induction-status-area-height">  
						<Bar data={data} width={barChartConfig.width} height={barChartConfig.height} 
							options={{ maintainAspectRatio: false, 
							legend: {
								display: barChartConfig.displayLegend
							},
							scales: {
								xAxes: [{
									position: barChartConfig.xAxisTicksPosition,
									barPercentage: barChartConfig.barPercentage,
									ticks: {
										fontSize: barChartConfig.xAxisTicksFontSize,
										fontWeight: barChartConfig.xAxisTickFontWeight
									},
									gridLines : {
						                display : barChartConfig.xAxisDisplayGridLines
						            } 
								}],
								yAxes: [{
									position: barChartConfig.yAxisTicksPosition,
									ticks: {
										fontSize: barChartConfig.yAxisTicksFontSize,
										fontWeight:barChartConfig.yAxisTickFontWeight
									},
									gridLines : {
						                display :barChartConfig.yAxisDisplayGridLines
						            }
								}]
							}  }}
						/> 
					</div>
					<div class="right-arrow_induct col-md-1 col-xl-1 col-sm-1 col-ls-1">
						<Link to={{ pathname: `/app/dashboard/${this.props.nextLink}/inductDetails`}}>
							&#x203A;
						</Link>
					</div>

				</RctCollapsibleCard>
			</div>
		);
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(InductionStatus));